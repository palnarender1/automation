package com.usbank.cashflow.service;

public class Calculator {
    public int add(int a, int b) {
        return a + b;
    }
}